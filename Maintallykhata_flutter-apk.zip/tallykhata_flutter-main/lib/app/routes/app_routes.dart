part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const SPLASH = _Paths.SPLASH;
  static const AUTH = _Paths.AUTH;
  static const OTP = _Paths.OTP;
  static const PROFILE_SETUP = _Paths.AUTH + _Paths.PROFILE_SETUP;
  static const WELCOME = _Paths.AUTH + _Paths.WELCOME;
  static const ADD = _Paths.ADD;
  static const TRANSACTION = _Paths.TRANSACTION;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const SPLASH = '/splash';
  static const AUTH = '/auth';
  static const OTP = '/otp';
  static const PROFILE_SETUP = '/profile-setup';
  static const WELCOME = '/welcome';
  static const ADD = '/add';
  static const TRANSACTION = '/transaction';
}
