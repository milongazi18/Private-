import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tallykhata/exports.dart';

class CustomerListTile extends StatelessWidget {
  final Map person;
  final bool isTrxScreen;

  const CustomerListTile({
    super.key,
    required this.person,
    this.isTrxScreen = false,
  });

  double _amount(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse((value ?? '0').toString().replaceAll(',', '')) ?? 0;
  }

  String _money(double value) => value.abs().toStringAsFixed(2);

  @override
  Widget build(BuildContext context) {
    final customerId = (person['id'] ?? person['phone'] ?? '').toString();
    final transactionStream = customerId.isEmpty
        ? const Stream<QuerySnapshot<Map<String, dynamic>>>.empty()
        : FirebaseService.to.firestore
            .collection('customers')
            .doc(customerId)
            .collection('transaction')
            .orderBy('created_at', descending: true)
            .snapshots();

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: transactionStream,
      builder: (context, snapshot) {
        var given = 0.0;
        var received = 0.0;
        DateTime? latestDate;
        for (final doc in snapshot.data?.docs ?? []) {
          final data = doc.data();
          given += _amount(data['dilam']);
          received += _amount(data['pelam']);
          final rawDate = data['created_at'] ?? data['data_for_date'];
          final date = rawDate is Timestamp
              ? rawDate.toDate()
              : DateTime.tryParse(rawDate?.toString() ?? '');
          if (date != null && (latestDate == null || date.isAfter(latestDate))) {
            latestDate = date;
          }
        }

        final isSupplier = person['user_type'] == 'supplier';
        final net = isSupplier ? received - given : given - received;
        final isPayable = net < 0;
        final duration = latestDate == null
            ? 'কোনো লেনদেন নেই'
            : '${DateTime.now().difference(latestDate).inDays} দিন আগে';

        return ListTile(
          onTap: isTrxScreen
              ? null
              : () => Get.toNamed(Routes.TRANSACTION, arguments: person),
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(
            child: Center(
              child: Text(
                person['name']
                    .toString()
                    .split(' ')
                    .where((word) => word.isNotEmpty)
                    .map((word) => word[0])
                    .join(),
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          title: Text(
            person['name'],
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          subtitle: Text(isTrxScreen ? '${person['phone']}' : duration),
          trailing: isTrxScreen
              ? null
              : SizedBox(
                  width: MediaQueryUtils.width * .2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        _money(net),
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          color: isPayable ? Colors.green : Colors.red,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Icon(Icons.arrow_forward_ios, size: 15),
                    ],
                  ),
                ),
        );
      },
    );
  }
}
