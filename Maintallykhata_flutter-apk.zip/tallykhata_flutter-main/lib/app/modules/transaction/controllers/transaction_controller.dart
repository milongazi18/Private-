import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:tallykhata/app/widgets/snackbar.dart';
import 'package:tallykhata/exports.dart';

class TransactionController extends GetxController {
  final selectedDate = DateTime.now().obs;
  RxString dilam = ''.obs;
  RxString pelam = ''.obs;
  RxString biboron = ''.obs;
  final _firestore = FirebaseService.to.firestore;
  final RxBool isLoading = false.obs;

  double? _parseAmount(String value) {
    final normalized = value.trim().replaceAll(',', '');
    if (normalized.isEmpty) return 0;
    final amount = double.tryParse(normalized);
    if (amount == null || !amount.isFinite || amount < 0) return null;
    return amount;
  }

  Future<void> submitTrx(String customerID) async {
    final user = FirebaseService.to.auth.currentUser;
    if (user == null) {
      snackBar('প্রথমে লগইন করুন।');
      return;
    }
    final give = _parseAmount(dilam.value);
    final receive = _parseAmount(pelam.value);
    if (give == null || receive == null) {
      snackBar('সঠিক টাকার পরিমাণ লিখুন।');
      return;
    }
    if (give == 0 && receive == 0) {
      snackBar('দিলাম অথবা পেলাম-এর ঘরে টাকার পরিমাণ লিখুন।');
      return;
    }
    if (customerID.trim().isEmpty || isLoading.value) return;

    isLoading.value = true;
    try {
      final customerRef = _firestore.collection('customers').doc(customerID);
      final customer = await customerRef.get();
      if (!customer.exists || customer.data()?['created_by_uid'] != user.uid) {
        snackBar('কাস্টমারের তথ্য পাওয়া যায়নি।');
        return;
      }
      await customerRef.collection('transaction').add({
        'dilam': give,
        'pelam': receive,
        'biboron': biboron.value.trim(),
        'created_by_uid': user.uid,
        'created_at': FieldValue.serverTimestamp(),
        'data_for_date': Timestamp.fromDate(selectedDate.value),
      });
      snackBar('ডাটা সফলভাবে সংরক্ষিত হয়েছে!');
      Get.back();
    } on FirebaseException catch (e) {
      snackBar(e.message ?? 'লেনদেন সংরক্ষণ করা যায়নি।');
    } catch (e) {
      snackBar('লেনদেন সংরক্ষণে সমস্যা হয়েছে।');
    } finally {
      isLoading.value = false;
    }
  }
}
