import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:tallykhata/app/widgets/custom_app_bar.dart';
import 'package:tallykhata/app/widgets/custom_text_field.dart';
import 'package:tallykhata/app/widgets/customer_list_tile.dart';
import 'package:tallykhata/exports.dart';

import '../controllers/transaction_controller.dart';

class TransactionView extends GetView<TransactionController> {
  const TransactionView({super.key});

  @override
  Widget build(BuildContext context) {
    final person = Get.arguments;

    return Scaffold(
      appBar: CustomAppBar(
        title: CustomerListTile(
          person: person,
          isTrxScreen: true,
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: FirebaseService.to.firestore
                      .collection('customers')
                      .doc((person['id'] ?? person['phone']).toString())
                      .collection('transaction')
                      .snapshots(),
                  builder: (context, snapshot) {
                    var given = 0.0;
                    var received = 0.0;
                    for (final doc in snapshot.data?.docs ?? []) {
                      final data = doc.data();
                      final rawGiven = data['dilam'];
                      final rawReceived = data['pelam'];
                      given += rawGiven is num
                          ? rawGiven.toDouble()
                          : double.tryParse((rawGiven ?? '0').toString().replaceAll(',', '')) ?? 0;
                      received += rawReceived is num
                          ? rawReceived.toDouble()
                          : double.tryParse((rawReceived ?? '0').toString().replaceAll(',', '')) ?? 0;
                    }
                    final isSupplier = person['user_type'] == 'supplier';
                    final balance = isSupplier ? received - given : given - received;
                    final label = balance < 0
                        ? (isSupplier ? 'পাবো' : 'দেবো')
                        : (isSupplier ? 'দেবো' : 'পাবো');
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('$labelঃ ৳${balance.abs().toStringAsFixed(2)}'),
                        Text(snapshot.hasData ? 'মোট লেনদেন ${snapshot.data!.docs.length}টি' : 'হিসাব লোড হচ্ছে'),
                      ],
                    );
                  },
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(
                  color: Colors.black.withOpacity(.1),
                ),
                SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    Expanded(
                      child: CustomTextField(
                        labelText: 'দিলাম/বেচা',
                        hintText: 'দিলাম/বেচা',
                        leadingIcon: Icons.attach_money,
                        onChanged: (value) {
                          controller.dilam.value = value;
                        },
                      ),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Expanded(
                      child: CustomTextField(
                        labelText: 'পেলাম',
                        hintText: 'পেলাম',
                        leadingIcon: Icons.attach_money,
                        onChanged: (value) {
                          controller.pelam.value = value;
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                CustomTextField(
                  labelText: 'বিবরণ',
                  hintText: 'বিবরণ',
                  leadingIcon: Icons.edit_note_sharp,
                  onChanged: (value) {
                    controller.biboron.value = value;
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Obx(
                      () => _buildRoundedButton(
                          icon: Icons.date_range,
                          label:
                              '${controller.selectedDate.value.day}-${controller.selectedDate.value.month}-${controller.selectedDate.value.year}',
                          onTap: () async {
                            final pickedDate = await showDatePicker(
                              context: context,
                              initialDate: controller.selectedDate.value,
                              firstDate: DateTime(2000),
                              lastDate: DateTime(2100),
                            );

                            if (pickedDate != null) {
                              controller.selectedDate.value = pickedDate;
                            }
                          }),
                    ),
                    _buildRoundedButton(
                      icon: Icons.add_a_photo_outlined,
                      label: 'ছবি',
                    ),
                  ],
                )
              ],
            ),
            Obx(
              () => CustomButton(
                label: 'নিশ্চিত',
                isLoading: controller.isLoading.value,
                buttonType:
                    controller.dilam.isNotEmpty || controller.pelam.isNotEmpty
                        ? ButtonType.ENABLED
                        : ButtonType.DISABLED,
                onTap: () => controller.submitTrx((person['id'] ?? person['phone']).toString()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _buildRoundedButton({
  required IconData icon,
  required String label,
  Widget? trailing,
  VoidCallback? onTap,
}) {
  return InkWell(
    onTap: onTap,
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.grey.shade700),
          SizedBox(width: 5),
          Text(label, style: TextStyle(color: Colors.black, fontSize: 14)),
          if (trailing != null) ...[
            SizedBox(width: 5),
            trailing,
          ]
        ],
      ),
    ),
  );
}
