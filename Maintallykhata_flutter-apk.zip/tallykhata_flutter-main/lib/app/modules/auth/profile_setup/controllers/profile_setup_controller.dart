import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tallykhata/app/widgets/snackbar.dart';
import 'package:tallykhata/exports.dart';

class ProfileSetupController extends GetxController {
  RxString businessName = ''.obs;
  RxBool isSettingUp = false.obs;

  final firestore = FirebaseService.to.firestore;

  Future<void> finishSetup() async {
    final user = FirebaseService.to.auth.currentUser;
    if (user == null || user.phoneNumber == null) {
      snackBar('কোন ব্যবহারকারী পাওয়া যায়নি');
      return;
    }
    final name = businessName.value.trim();
    if (name.isEmpty) {
      snackBar('ব্যবসার নাম লিখুন।');
      return;
    }
    if (isSettingUp.value) return;

    isSettingUp.value = true;
    try {
      await firestore.collection('users').doc(user.phoneNumber).set({
        'business_name': name,
        'phone_number': user.phoneNumber,
        'uid': user.uid,
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      snackBar('প্রোফাইল সফলভাবে সংরক্ষণ করা হয়েছে!');
      Get.offAllNamed(Routes.WELCOME);
    } on FirebaseException catch (e) {
      snackBar(e.message ?? 'প্রোফাইল সংরক্ষণ করা যায়নি।');
    } catch (e) {
      snackBar('প্রোফাইল সংরক্ষণে সমস্যা হয়েছে।');
    } finally {
      isSettingUp.value = false;
    }
  }
}
