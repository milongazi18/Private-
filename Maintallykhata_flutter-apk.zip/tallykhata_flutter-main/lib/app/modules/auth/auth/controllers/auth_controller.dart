import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:tallykhata/app/widgets/snackbar.dart';
import 'package:tallykhata/exports.dart';

class AuthController extends GetxController {
  final RxString number = ''.obs;
  final RxString numberWithCountryCode = ''.obs;
  final RxString otp = ''.obs;

  final numberController = TextEditingController();
  final RxBool isOTPVerifying = false.obs;
  final RxBool isOTPSending = false.obs;
  final RxString verificationID = ''.obs;
  final List<TextEditingController> otpControllers =
      List.generate(6, (_) => TextEditingController());

  final RxInt seconds = 15.obs;
  final RxBool isTimerActive = false.obs;

  FirebaseAuth get auth => FirebaseService.to.auth;
  FirebaseFirestore get firestore => FirebaseService.to.firestore;

  int? _resendToken;
  Timer? _timer;

  Future<void> loginOrRegister() async {
    if (number.value.length != 10 || !number.value.startsWith('1')) {
      snackBar('সঠিক ১০ ডিজিটের মোবাইল নম্বর দিন।');
      return;
    }
    await _sendVerificationCode();
  }

  Future<void> _sendVerificationCode({int? forceResendingToken}) async {
    if (isOTPSending.value) return;
    isOTPSending.value = true;
    try {
      await auth.verifyPhoneNumber(
        phoneNumber: numberWithCountryCode.value,
        forceResendingToken: forceResendingToken,
        verificationCompleted: (PhoneAuthCredential credential) async {
          try {
            await _signInWithInfo(credential);
          } on FirebaseAuthException catch (e) {
            snackBar(e.message ?? 'ভেরিফিকেশন সম্পন্ন করা যায়নি।');
          } catch (e) {
            snackBar('ভেরিফিকেশনে সমস্যা হয়েছে।');
          }
        },
        verificationFailed: (FirebaseAuthException error) {
          isOTPSending.value = false;
          final message = error.code == 'invalid-phone-number'
              ? 'আপনার মোবাইল নাম্বারটি সঠিক নয়।'
              : (error.message ?? 'OTP পাঠানো যায়নি।');
          snackBar(message);
        },
        codeSent: (String id, int? resendToken) {
          isOTPSending.value = false;
          verificationID.value = id;
          _resendToken = resendToken;
          _clearOtpFields();
          snackBar('আপনার মোবাইলের ভেরিফিকেশন কোড পাঠানো হয়েছে');
          if (Get.currentRoute != Routes.OTP) Get.toNamed(Routes.OTP);
          startTimer();
        },
        codeAutoRetrievalTimeout: (String id) {
          verificationID.value = id;
          isOTPSending.value = false;
        },
      );
    } on FirebaseAuthException catch (e) {
      isOTPSending.value = false;
      snackBar(e.message ?? 'OTP পাঠানো যায়নি।');
    } catch (e) {
      isOTPSending.value = false;
      snackBar('OTP পাঠাতে সমস্যা হয়েছে।');
    }
  }

  Future<void> verifyOTP() async {
    if (verificationID.value.isEmpty || otp.value.length != 6) {
      snackBar('৬ ডিজিটের ভেরিফিকেশন কোড দিন।');
      return;
    }
    if (isOTPVerifying.value) return;
    isOTPVerifying.value = true;
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationID.value,
        smsCode: otp.value,
      );
      await _signInWithInfo(credential);
    } on FirebaseAuthException catch (e) {
      snackBar(e.message ?? 'ভেরিফিকেশন কোড সঠিক নয়।');
    } catch (e) {
      snackBar('একটি সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      isOTPVerifying.value = false;
    }
  }

  Future<UserCredential> _signInWithInfo(AuthCredential credential) async {
    final userData = await auth.signInWithCredential(credential);
    final user = userData.user;
    if (user == null || user.phoneNumber == null) {
      throw FirebaseAuthException(
        code: 'user-not-found',
        message: 'ব্যবহারকারীর তথ্য পাওয়া যায়নি।',
      );
    }

    final userDoc = await firestore.collection('users').doc(user.phoneNumber).get();
    snackBar('আপনার ভেরিফিকেশন সফল হয়েছে!');
    if (userDoc.exists) {
      Get.offAllNamed(Routes.HOME);
    } else {
      Get.offAllNamed(Routes.PROFILE_SETUP);
    }
    return userData;
  }

  void onOTPChanged(String value, int index, BuildContext context) {
    if (value.length == 1 && index < otpControllers.length - 1) {
      FocusScope.of(context).nextFocus();
    } else if (value.isEmpty && index > 0) {
      FocusScope.of(context).previousFocus();
    }
    otp.value = otpControllers.map((controller) => controller.text).join();
  }

  void _clearOtpFields() {
    for (final controller in otpControllers) {
      controller.clear();
    }
    otp.value = '';
  }

  void startTimer() {
    _timer?.cancel();
    isTimerActive.value = true;
    seconds.value = 15;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (seconds.value > 0) {
        seconds.value--;
      } else {
        isTimerActive.value = false;
        timer.cancel();
      }
    });
  }

  Future<void> resendOtp() async {
    if (isTimerActive.value || isOTPSending.value) return;
    if (numberWithCountryCode.value.isEmpty) {
      snackBar('মোবাইল নম্বর পাওয়া যায়নি। আবার লগইন করুন।');
      return;
    }
    await _sendVerificationCode(forceResendingToken: _resendToken);
  }

  @override
  void onClose() {
    _timer?.cancel();
    numberController.dispose();
    for (final controller in otpControllers) {
      controller.dispose();
    }
    super.onClose();
  }
}
