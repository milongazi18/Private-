import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tallykhata/app/widgets/snackbar.dart';
import 'package:tallykhata/exports.dart';

class AddController extends GetxController {
  RxString selectedValue = 'customer'.obs;
  RxString name = ''.obs;
  RxString phone = ''.obs;
  RxBool isLoading = false.obs;

  final _fireStore = FirebaseService.to.firestore;
  final currentUser = FirebaseService.to.auth.currentUser;

  Future<void> addCustomerOrSupplier() async {
    final user = currentUser;
    final cleanName = name.value.trim();
    final cleanPhone = phone.value.replaceAll(RegExp(r'\s+'), '');
    if (user == null) {
      snackBar('প্রথমে লগইন করুন।');
      return;
    }
    if (cleanName.isEmpty) {
      snackBar('নাম লিখুন।');
      return;
    }
    if (cleanPhone.length < 10) {
      snackBar('সঠিক মোবাইল নম্বর লিখুন।');
      return;
    }
    if (isLoading.value) return;

    isLoading.value = true;
    try {
      final customerRef = _fireStore.collection('customers').doc(cleanPhone);
      final existing = await customerRef.get();
      if (existing.exists && existing.data()?['created_by_uid'] != user.uid) {
        snackBar('এই নম্বরটি অন্য একটি অ্যাকাউন্টে ব্যবহৃত হয়েছে।');
        return;
      }
      final now = FieldValue.serverTimestamp();
      await customerRef.set({
        'name': cleanName,
        'phone': cleanPhone,
        'user_type': selectedValue.value,
        'created_by_uid': user.uid,
        'created_by_phone': user.phoneNumber,
        'created_at': existing.data()?['created_at'] ?? now,
        'updated_at': now,
      }, SetOptions(merge: true));

      snackBar('${selectedValue.value == 'customer' ? 'কাস্টমার' : 'সাপ্লায়ার'} সফলভাবে যুক্ত হয়েছে');
      Get.back();
    } on FirebaseException catch (e) {
      snackBar(e.message ?? 'তথ্য সংরক্ষণ করা যায়নি।');
    } catch (e) {
      snackBar('একটি সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      isLoading.value = false;
    }
  }
}
