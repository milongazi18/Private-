# Maintallykhata Flutter — Repair Notes

## UI preservation
- Existing screen layouts, colors, spacing, widgets, and assets were retained.
- Changes were limited to controller/data behavior and small data-binding changes in existing screens.

## Changes in this pass
- Fixed OTP verification to await Firebase sign-in and surface errors.
- Implemented real OTP resend using Firebase's resend token, with timer cancellation and OTP field reset.
- Added input validation and duplicate-owner protection when saving a customer/supplier.
- Added profile-save validation and error handling.
- Added transaction amount validation, numeric storage, owner metadata, and customer ownership checks.
- Changed the customer query to scope records by authenticated UID.
- Connected the existing customer list, customer balances, account totals, and transaction summary to Firestore transaction data.
- Added `firestore.rules` and registered it in `firebase.json`.

## Before running
1. Install Flutter SDK compatible with the Android Gradle setup.
2. From the project root run `flutter pub get`.
3. In Firebase Console, confirm Phone Authentication is enabled for project `tallykhata-aecfa`.
4. Confirm Firestore Database exists.
5. Review `firestore.rules` against your existing database records before deploying. Existing customer documents must have `created_by_uid` matching their owner UID.
6. Deploy rules only after review: `firebase deploy --only firestore:rules`.
7. Run `flutter analyze`, then `flutter run` on a real Android device for phone OTP testing.

## Verification limitation
The current environment does not have the Flutter or Dart SDK installed. Therefore dependency resolution, Dart analysis, emulator/device runtime testing, Firebase OTP delivery, and APK generation were not run. This ZIP is a source-code repair pass, not a certified release build.

## Known remaining work
- Search/filter and phonebook import controls are still placeholders in the original UI.
- Transaction history is stored in Firestore; a dedicated history list/edit/delete workflow is not part of this pass.
- Image attachment, backup/export, and secondary dashboard menu features remain to be implemented.
- Account totals use the app's current `dilam`/`pelam` interpretation; verify the accounting direction with real business examples before production use.
